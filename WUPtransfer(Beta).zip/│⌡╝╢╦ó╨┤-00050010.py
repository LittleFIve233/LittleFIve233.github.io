import wupclient

if __name__ == '__main__':
    print("说明：使用该脚本你已经自行承担了变砖风险，一切砖机与开发者无关")
    print("\n")
    print("尝试连接到wupserver...")
    w = wupclient.wupclient()
    if(w.s == None):
        print("无法连接wupserver！")
        exit()
    print("已连接！")
    wupclient.w = w
    print("尝试挂载SD卡...")
    ret = wupclient.mount_sd()
    if(ret == 0):
        print("无法挂载SD！")
    else:
        print("挂载成功！开始执行WUPtransfer")
        ret = w.cpdir("/vol/storage_sdcard/WUPtransfer/title", "/vol/storage_mlc01/sys/title")
    import os 
    os.system('pause')
    if(w.fsa_handle != None):
        w.close(w.fsa_handle)
        w.fsa_handle = None
    if(w.s != None):
        w.s.close()
        w.s = None
